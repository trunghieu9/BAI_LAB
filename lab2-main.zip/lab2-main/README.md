<div align = center>
<h1>ML_Lab_2</h1>
</div>

## 1. Công nghệ sử dụng:

 - Framework: pandas, sckit-learn

## 2. Thuật toán:

 - Naive Bayes (Phân phối Bernoulli, Multinomial và Gaussian)

## 3. Hiển thị kết quả lên website:

![Ketquaweb1](web1.JPG)

![Ketquaweb2](web2.JBG)

## 4. So sánh 2 của 2 phân phối Bernoulli và Multinomial, Đánh giá mô hình phân phối Gaussian:

 - Câu 1:

![Cau1](cau1.png)

 - Câu 2:

![Cau2](cau2.png)
